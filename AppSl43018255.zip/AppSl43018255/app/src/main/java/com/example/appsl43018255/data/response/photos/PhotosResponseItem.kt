package com.example.appsl43018255.data.response.photos

data class PhotosResponseItem(
    val albumId: Int,
    val id: Int,
    val thumbnailUrl: String,
    val title: String,
    val url: String
):java.io.Serializable