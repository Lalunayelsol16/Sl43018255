package com.example.appsl48399119.data.retrofit

class MainRepository(private val callApi: CallApi) {

    suspend fun getPhotos() = CallApi.retrofitService?.getPhotos()
    suspend fun getTodos() = CallApi.retrofitService?.getTodos()

}